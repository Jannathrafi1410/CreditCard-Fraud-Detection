"""
Interactive Credit Card Fraud Detection Dashboard.
Built with Streamlit, Plotly, Pandas, and Scikit-Learn.
Provides real-time model inference, batch scoring, EDA diagnostics, and operational monitoring.
"""

import os
import sys
import json
import joblib
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.preprocessing import DataPreprocessor
from src.predict import FraudPredictor

# Page Configuration
st.set_page_config(
    page_title="Credit Card Fraud Detection | ML & Big Data Analytics",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1e3a8a;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #4b5563;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #f8fafc;
        border-radius: 8px;
        padding: 16px;
        border: 1px solid #e2e8f0;
    }
    .badge-fraud {
        background-color: #fee2e2;
        color: #991b1b;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
    }
    .badge-legit {
        background-color: #dcfce7;
        color: #166534;
        padding: 4px 10px;
        border-radius: 6px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_predictor():
    model_path = os.path.join(PROJECT_ROOT, "models", "random_forest_model.joblib")
    scaler_path = os.path.join(PROJECT_ROOT, "models", "scaler.joblib")
    if os.path.exists(model_path) and os.path.exists(scaler_path):
        return FraudPredictor(model_path=model_path, preprocessor_path=scaler_path)
    return None


@st.cache_data
def load_metrics():
    metrics_path = os.path.join(PROJECT_ROOT, "reports", "metrics", "evaluation_metrics.json")
    if os.path.exists(metrics_path):
        with open(metrics_path, "r") as f:
            return json.load(f)
    return None


@st.cache_data
def load_dataset_summary():
    summary_path = os.path.join(PROJECT_ROOT, "reports", "metrics", "dataset_inspection.json")
    if os.path.exists(summary_path):
        with open(summary_path, "r") as f:
            return json.load(f)
    return None


predictor = load_predictor()
metrics = load_metrics()
dataset_stats = load_dataset_summary()

# Sidebar Navigation
st.sidebar.image("https://img.icons8.com/fluency/96/bank-card-back-side.png", width=64)
st.sidebar.title("Navigation")
page = st.sidebar.radio(
    "Select System Module:",
    [
        "1. Project Overview",
        "2. Dataset Inspection",
        "3. Exploratory Data Analysis",
        "4. Model Performance & Evaluation",
        "5. Single Transaction Prediction",
        "6. Batch Transaction Scoring",
        "7. Operational Fraud Monitoring"
    ]
)

st.sidebar.markdown("---")
st.sidebar.markdown("**Architecture Stack**")
st.sidebar.markdown("""
- **Primary ML (Academic)**: R & Caret (Random Forest)
- **Interactive Engine**: Python & Scikit-Learn
- **Big Data Processing**: Apache Spark / PySpark
- **Distributed Store**: Apache Hadoop HDFS
- **Dashboard**: Streamlit & Plotly
""")

# ==============================================================================
# Page 1: Project Overview
# ==============================================================================
if page == "1. Project Overview":
    st.markdown('<div class="main-header">Credit Card Fraud Detection System</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">B.Tech Capstone Project: Machine Learning and Big Data Analytics Architecture</div>', unsafe_allow_html=True)

    col1, col2 = st.columns([2, 1])
    with col1:
        st.subheader("📌 Problem Statement")
        st.write("""
        Credit card fraud presents a critical challenge to global financial institutions. With trillions of dollars 
        processed annually across billions of digital transactions, fraudulent transactions constitute a microscopic fraction 
        (often < 0.2%) of overall transaction traffic. Traditional static rule-based engines suffer from high false alarm rates 
        and fail to detect evolving, non-linear fraud vectors.

        This project implements an **end-to-end, data-driven fraud detection architecture** that leverages 
        **Cost-Sensitive Random Forest Ensembles**, **Robust Scaling**, and **Distributed Big Data Analytics (PySpark & HDFS)** 
        to accurately classify transactions while minimizing false alarms on legitimate cardholders.
        """)

        st.subheader("🎯 Key Project Objectives")
        st.markdown("""
        1. **End-to-End Pipeline**: Ingest, clean, scale, and partition real European credit card transaction logs.
        2. **Class Imbalance Resolution**: Apply cost-sensitive loss weighting ($w_j = \\frac{n}{k \\cdot n_j}$) to penalize fraud misclassification without synthetic test distortion.
        3. **Dual Technology Stack**: Provide full R/Caret implementation alongside a Python/PySpark production workflow.
        4. **Distributed Big Data Engine**: Process large-scale transaction logs using Apache Spark DataFrames to compute hourly velocity and risk brackets.
        5. **Operational Interface**: Provide an interactive web dashboard for real-time scoring, batch audits, and risk assessment.
        """)

    with col2:
        st.subheader("💻 Technology Matrix")
        st.info("""
        **Core Algorithms:**
        - Random Forest (100 Trees, Depth 15)
        - Cost-Sensitive Class Weighting
        - Logistic Regression Baseline

        **Big Data Stack:**
        - Apache Spark (PySpark 4.2.0)
        - Hadoop HDFS Architecture
        - Distributed Aggregations

        **Evaluation Metrics:**
        - Precision, Recall, F1-Score
        - ROC-AUC & Precision-Recall AUC
        - Cost Matrix (TP, TN, FP, FN)
        """)

    st.markdown("---")
    st.subheader("📐 System Architecture Overview")
    arch_path = os.path.join(PROJECT_ROOT, "diagrams", "system_architecture.png")
    if os.path.exists(arch_path):
        st.image(arch_path, caption="End-to-End System Architecture: Machine Learning & Big Data Pipeline", use_container_width=True)

# ==============================================================================
# Page 2: Dataset Inspection
# ==============================================================================
elif page == "2. Dataset Inspection":
    st.markdown('<div class="main-header">Dataset Technical Inspection</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Verification and Schema Profiling of the Kaggle Credit Card Fraud Dataset (ULB Benchmark)</div>', unsafe_allow_html=True)

    if dataset_stats:
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Total Records", f"{dataset_stats['total_rows']:,}")
        m2.metric("Features", f"{dataset_stats['total_columns']}")
        m3.metric("Fraud Count", f"{dataset_stats['fraud_count']:,}", f"{dataset_stats['fraud_percentage']}%")
        m4.metric("Legitimate Count", f"{dataset_stats['legit_count']:,}", f"{dataset_stats['legit_percentage']}%")
        m5.metric("Missing Values", f"{dataset_stats['total_missing_values']}")

        st.markdown("---")
        c1, c2 = st.columns(2)
        with c1:
            st.subheader("Dataset Attributes & Privacy Protection")
            st.write("""
            - **Anonymization**: Features **V1 through V28** are numerical principal components extracted via **Principal Component Analysis (PCA)** to safeguard cardholder confidentiality.
            - **Temporal Dimension**: The `Time` feature denotes elapsed seconds from the first recorded transaction (spanning 48 hours = 172,792 seconds).
            - **Monetary Dimension**: The `Amount` feature represents transaction value (ranging from €0.00 to €25,691.16).
            - **Target Column**: Binary indicator `Class` (0 = Legitimate, 1 = Fraudulent).
            - **Duplicate Audit**: 1,081 rows (0.380%) identified as duplicate entries.
            """)

        with c2:
            fig_pie = go.Figure(data=[go.Pie(
                labels=["Legitimate (99.83%)", "Fraudulent (0.17%)"],
                values=[dataset_stats['legit_count'], dataset_stats['fraud_count']],
                hole=0.5,
                marker_colors=["#3b82f6", "#ef4444"]
            )])
            fig_pie.update_layout(title="Transaction Class Distribution (Severe Imbalance)", height=300, margin=dict(t=40, b=10, l=10, r=10))
            st.plotly_chart(fig_pie, use_container_width=True)

    # Preview Dataset
    sample_file = os.path.join(PROJECT_ROOT, "data", "sample", "sample_transactions.csv")
    if os.path.exists(sample_file):
        st.subheader("📋 Sample Transaction Records Preview (Anonymized Features)")
        sample_df = pd.read_csv(sample_file)
        st.dataframe(sample_df.head(10), use_container_width=True)

# ==============================================================================
# Page 3: Exploratory Data Analysis
# ==============================================================================
elif page == "3. Exploratory Data Analysis":
    st.markdown('<div class="main-header">Exploratory Data Analysis (EDA)</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Visual Profiling of Fraudulent Patterns, Amounts, and Temporal Dynamics</div>', unsafe_allow_html=True)

    tab1, tab2, tab3, tab4 = st.tabs(["Class & Amount Distributions", "Temporal Analysis", "Correlation Matrix", "Big Data Hourly Velocity"])

    with tab1:
        c1, c2 = st.columns(2)
        with c1:
            st.image(os.path.join(PROJECT_ROOT, "reports", "figures", "class_distribution.png"), caption="Log-Scale Class Distribution", use_container_width=True)
            st.caption("**Interpretation**: Legitimate transactions overwhelmingly dominate the dataset (99.827%), necessitating specialized imbalance mitigation.")
        with c2:
            st.image(os.path.join(PROJECT_ROOT, "reports", "figures", "amount_by_class_boxplot.png"), caption="Transaction Amount by Class", use_container_width=True)
            st.caption("**Interpretation**: Fraudulent transactions concentrate in moderate ranges (median ~€9.25), avoiding high-value thresholds that trigger manual verification.")

    with tab2:
        st.image(os.path.join(PROJECT_ROOT, "reports", "figures", "transaction_time_density.png"), caption="Transaction Density Across 48 Elapsed Hours", use_container_width=True)
        st.caption("**Interpretation**: Legitimate transactions clearly display cyclical diurnal patterns corresponding to daytime shopping hours, whereas fraudulent activity persists consistently across nighttime troughs.")

    with tab3:
        st.image(os.path.join(PROJECT_ROOT, "reports", "figures", "correlation_heatmap.png"), caption="Top 15 Features Correlated with Fraud Target", use_container_width=True)
        st.caption("**Interpretation**: Features V17, V14, V12, V10, and V11 exhibit the strongest linear and non-linear correlations with fraudulent transactions.")

    with tab4:
        st.subheader("PySpark Distributed Analytics: Hourly Transaction & Fraud Trends")
        spark_plot = os.path.join(PROJECT_ROOT, "reports", "figures", "spark_hourly_fraud_trends.png")
        if os.path.exists(spark_plot):
            st.image(spark_plot, caption="Apache Spark Distributed Output: Hourly Volume vs. Fraud Velocity", use_container_width=True)

        spark_summary = os.path.join(PROJECT_ROOT, "data", "processed", "spark_aggregated_metrics", "spark_amount_bracket_risk.csv")
        if os.path.exists(spark_summary):
            st.write("**Distributed Amount Bracket Risk Breakdown:**")
            bracket_df = pd.read_csv(spark_summary)
            st.dataframe(bracket_df, use_container_width=True)

# ==============================================================================
# Page 4: Model Performance & Evaluation
# ==============================================================================
elif page == "4. Model Performance & Evaluation":
    st.markdown('<div class="main-header">Model Performance & Evaluation</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Measured Metrics on Genuinely Held-Out Test Set (56,962 Transactions)</div>', unsafe_allow_html=True)

    if metrics:
        col1, col2, col3, col4, col5 = st.columns(5)
        col1.metric("Accuracy", f"{metrics['accuracy']*100:.3f}%")
        col2.metric("Precision", f"{metrics['precision']*100:.2f}%", help="Proportion of flagged transactions that were genuine frauds")
        col3.metric("Recall (Sensitivity)", f"{metrics['recall']*100:.2f}%", help="Proportion of actual frauds successfully caught")
        col4.metric("F1-Score", f"{metrics['f1_score']:.4f}", help="Harmonic mean of precision and recall")
        col5.metric("ROC-AUC", f"{metrics['roc_auc']:.4f}")

        st.markdown("---")
        c1, c2 = st.columns(2)
        with c1:
            st.subheader("Detailed Confusion Matrix (Held-Out Test Data)")
            cm = metrics["confusion_matrix"]
            cm_table = pd.DataFrame([
                {"Ground Truth": "Actual Legitimate (0)", "Predicted Legit (0)": f"{cm['true_negatives']:,} (TN)", "Predicted Fraud (1)": f"{cm['false_positives']} (FP)"},
                {"Ground Truth": "Actual Fraudulent (1)", "Predicted Legit (0)": f"{cm['false_negatives']} (FN)", "Predicted Fraud (1)": f"{cm['true_positives']} (TP)"}
            ]).set_index("Ground Truth")
            st.table(cm_table)

            st.write("""
            **Operational Matrix Interpretations:**
            - **True Positives (TP = 81)**: Fraudulent transactions correctly caught by the model.
            - **True Negatives (TN = 56,845)**: Legitimate transactions cleared for immediate settlement.
            - **False Positives (FP = 19)**: Legitimate cardholders temporarily held for secondary review (false alarm rate < 0.034%).
            - **False Negatives (FN = 17)**: Fraudulent transactions that bypassed detection.
            """)

        with c2:
            st.subheader("Benchmark Comparison: Random Forest vs. Baseline")
            bl = metrics.get("baseline_comparison", {})
            comp_df = pd.DataFrame([
                {"Metric": "Accuracy", "Random Forest (Ours)": f"{metrics['accuracy']*100:.2f}%", "Baseline Logistic Regression": f"{bl.get('accuracy', 0)*100:.2f}%"},
                {"Metric": "Precision", "Random Forest (Ours)": f"{metrics['precision']*100:.2f}%", "Baseline Logistic Regression": f"{bl.get('precision', 0)*100:.2f}%"},
                {"Metric": "Recall", "Random Forest (Ours)": f"{metrics['recall']*100:.2f}%", "Baseline Logistic Regression": f"{bl.get('recall', 0)*100:.2f}%"},
                {"Metric": "F1-Score", "Random Forest (Ours)": f"{metrics['f1_score']:.4f}", "Baseline Logistic Regression": f"{bl.get('f1_score', 0):.4f}"},
                {"Metric": "False Positives (Alarms)", "Random Forest (Ours)": f"{cm['false_positives']}", "Baseline Logistic Regression": f"{bl.get('confusion_matrix', {}).get('false_positives', 0):,}"},
                {"Metric": "PR-AUC", "Random Forest (Ours)": f"{metrics['pr_auc']:.4f}", "Baseline Logistic Regression": f"{bl.get('pr_auc', 0):.4f}"}
            ]).set_index("Metric")
            st.table(comp_df)
            st.info("""
            **Academic Insight**: While the baseline model claims 97.55% accuracy, its precision is only 6.09% with **1,388 false alarms**. 
            Random Forest reduces false alarms by **98.6%** (down to 19) while maintaining high detection recall!
            """)

        st.markdown("---")
        st.subheader("Diagnostic Curves & Feature Rankings")
        row1, row2, row3 = st.columns(3)
        with row1:
            st.image(os.path.join(PROJECT_ROOT, "reports", "figures", "confusion_matrix.png"), caption="Confusion Matrix Heatmap", use_container_width=True)
        with row2:
            st.image(os.path.join(PROJECT_ROOT, "reports", "figures", "roc_curve.png"), caption="ROC Curve", use_container_width=True)
        with row3:
            st.image(os.path.join(PROJECT_ROOT, "reports", "figures", "precision_recall_curve.png"), caption="Precision-Recall Curve", use_container_width=True)

        st.image(os.path.join(PROJECT_ROOT, "reports", "figures", "feature_importance.png"), caption="Top 15 Predictive Features by Gini Importance", use_container_width=True)

# ==============================================================================
# Page 5: Single Transaction Prediction
# ==============================================================================
elif page == "5. Single Transaction Prediction":
    st.markdown('<div class="main-header">Single Transaction Risk Assessment</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Evaluate Real-Time Transaction Features with Calibrated Ensembles</div>', unsafe_allow_html=True)

    if predictor is None:
        st.error("Trained model artifact not found. Please run the training pipeline first.")
    else:
        # Provide sample test presets
        st.write("💡 **Quick Test Presets (Click to Auto-fill Demo Records):**")
        pcol1, pcol2, pcol3 = st.columns([1, 1, 2])
        preset = None
        if pcol1.button("🟢 Load Typical Legitimate Record"):
            preset = "legit"
        if pcol2.button("🔴 Load Known Fraudulent Record"):
            preset = "fraud"

        # Preset values from actual dataset
        if preset == "fraud":
            default_time = 406.0
            default_amount = 239.93
            v_defaults = {
                "V1": -2.31, "V2": 1.95, "V3": -1.61, "V4": 3.99, "V5": -0.52,
                "V6": -1.43, "V7": -2.54, "V8": 1.56, "V9": -2.77, "V10": -2.77,
                "V11": 3.20, "V12": -2.90, "V13": -0.60, "V14": -4.29, "V15": 0.39,
                "V16": -1.14, "V17": -2.83, "V18": -0.02, "V19": 0.42, "V20": 0.13,
                "V21": 0.52, "V22": -0.04, "V23": -0.47, "V24": 0.32, "V25": 0.04,
                "V26": 0.18, "V27": 0.26, "V28": -0.14
            }
        else:
            default_time = 85000.0
            default_amount = 45.50
            v_defaults = {f"V{i}": 0.05 for i in range(1, 29)}

        with st.form("transaction_form"):
            st.subheader("Transaction Parameters")
            fcol1, fcol2, fcol3 = st.columns(3)
            with fcol1:
                input_time = st.number_input("Time Elapsed (seconds)", value=float(default_time), min_value=0.0)
            with fcol2:
                input_amount = st.number_input("Transaction Amount ($/€)", value=float(default_amount), min_value=0.0)
            with fcol3:
                threshold = st.slider("Decision Cutoff Threshold", min_value=0.10, max_value=0.90, value=0.50, step=0.05)

            st.markdown("##### Anonymized PCA Vector Features (V1 to V28)")
            cols = st.columns(7)
            v_inputs = {}
            for i in range(1, 29):
                col_idx = (i - 1) % 7
                with cols[col_idx]:
                    v_inputs[f"V{i}"] = st.number_input(f"V{i}", value=float(v_defaults.get(f"V{i}", 0.0)), format="%.3f")

            submitted = st.form_submit_button("⚡ Evaluate Transaction Risk")

        if submitted:
            record = {"Time": input_time, "Amount": input_amount}
            record.update(v_inputs)

            result = predictor.predict_single(record, threshold=threshold)

            st.markdown("---")
            st.subheader("Inference Result & Operational Directive")

            r1, r2, r3 = st.columns([1, 1, 2])
            with r1:
                st.metric("Predicted Status", result["prediction_label"])
            with r2:
                st.metric("Fraud Probability", f"{result['fraud_probability']*100:.2f}%")
            with r3:
                st.metric("Risk Classification Tier", result["risk_tier"])

            # Probability Gauge
            fig_gauge = go.Figure(go.Indicator(
                mode="gauge+number",
                value=result["fraud_probability"] * 100,
                domain={'x': [0, 1], 'y': [0, 1]},
                title={'text': "Fraud Risk Score (%)", 'font': {'size': 18}},
                gauge={
                    'axis': {'range': [0, 100], 'tickwidth': 1},
                    'bar': {'color': "#dc2626" if result["prediction"] == 1 else "#16a34a"},
                    'steps': [
                        {'range': [0, 20], 'color': "#dcfce7"},
                        {'range': [20, threshold*100], 'color': "#fef9c3"},
                        {'range': [threshold*100, 80], 'color': "#fee2e2"},
                        {'range': [80, 100], 'color': "#fca5a5"}
                    ],
                    'threshold': {
                        'line': {'color': "black", 'width': 3},
                        'thickness': 0.75,
                        'value': threshold * 100
                    }
                }
            ))
            fig_gauge.update_layout(height=260, margin=dict(t=30, b=10, l=20, r=20))
            st.plotly_chart(fig_gauge, use_container_width=True)

            if result["prediction"] == 1:
                st.error(f"🚨 **ALERT**: {result['operational_verdict']}")
            else:
                st.success(f"✅ **APPROVED**: {result['operational_verdict']}")

            st.caption(result["disclaimer"])

# ==============================================================================
# Page 6: Batch Transaction Scoring
# ==============================================================================
elif page == "6. Batch Transaction Scoring":
    st.markdown('<div class="main-header">Batch Transaction Scoring Engine</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">High-Throughput Risk Scoring for Unlabeled or Historical CSV Feeds</div>', unsafe_allow_html=True)

    if predictor is None:
        st.error("Trained model artifact not found.")
    else:
        st.write("Upload a CSV file containing transactions, or score the pre-loaded 50-transaction test batch.")
        
        batch_col1, batch_col2 = st.columns([1, 1])
        load_sample = batch_col1.button("📥 Load Built-in Test Batch (50 records)")
        uploaded_file = batch_col2.file_uploader("Or Upload Custom CSV", type=["csv"])

        df_to_score = None
        if load_sample:
            sample_batch_path = os.path.join(PROJECT_ROOT, "data", "sample", "test_batch_transactions.csv")
            if os.path.exists(sample_batch_path):
                df_to_score = pd.read_csv(sample_batch_path)
                st.success(f"Loaded {len(df_to_score)} transactions from sample test batch.")
            else:
                st.error("Sample batch file not found.")
        elif uploaded_file is not None:
            df_to_score = pd.read_csv(uploaded_file)
            st.success(f"Uploaded file with {len(df_to_score)} transactions.")

        if df_to_score is not None:
            batch_threshold = st.slider("Select Fraud Probability Threshold for Batch Scoring", 0.10, 0.90, 0.50, 0.05)
            
            try:
                scored_df = predictor.predict_batch(df_to_score, threshold=batch_threshold)
                
                # Display Summary Metrics
                total_scored = len(scored_df)
                flagged_count = (scored_df["Predicted_Class"] == 1).sum()
                cleared_count = total_scored - flagged_count
                flagged_pct = (flagged_count / total_scored) * 100

                m1, m2, m3, m4 = st.columns(4)
                m1.metric("Total Transactions", f"{total_scored:,}")
                m2.metric("Flagged for Investigation", f"{flagged_count:,}", f"{flagged_pct:.2f}%")
                m3.metric("Approved Legitimate", f"{cleared_count:,}")
                m4.metric("Avg Fraud Score", f"{scored_df['Fraud_Probability'].mean()*100:.2f}%")

                st.markdown("---")
                st.subheader("Scored Transaction Data Table")
                st.dataframe(scored_df[["Fraud_Probability", "Predicted_Class", "Prediction_Label", "Risk_Tier", "Amount", "Time"]].head(25), use_container_width=True)

                # Download Scored CSV
                csv_bytes = scored_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="💾 Download Scored Transactions CSV",
                    data=csv_bytes,
                    file_name="fraud_scored_transactions.csv",
                    mime="text/csv"
                )

            except Exception as e:
                st.error(f"Error scoring batch: {e}")

# ==============================================================================
# Page 7: Operational Fraud Monitoring
# ==============================================================================
elif page == "7. Operational Fraud Monitoring":
    st.markdown('<div class="main-header">Operational Fraud Monitoring Dashboard</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Operational Summaries, Risk Tiers, and Suspicious Activity Review</div>', unsafe_allow_html=True)

    scored_sample_path = os.path.join(PROJECT_ROOT, "data", "sample", "sample_transactions.csv")
    if os.path.exists(scored_sample_path) and predictor is not None:
        sample_df = pd.read_csv(scored_sample_path)
        scored = predictor.predict_batch(sample_df)

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Transactions Monitored", f"{len(scored):,}")
        flagged = (scored["Predicted_Class"] == 1).sum()
        c2.metric("Suspicious Alerts", f"{flagged:,}", f"{flagged/len(scored)*100:.1f}%")
        total_risk_exposure = scored[scored["Predicted_Class"] == 1]["Amount"].sum()
        c3.metric("Monetary Exposure at Risk", f"${total_risk_exposure:,.2f}")
        c4.metric("Active Decision Threshold", "0.50")

        st.markdown("---")
        col_chart1, col_chart2 = st.columns(2)
        with col_chart1:
            tier_counts = scored["Risk_Tier"].value_counts().reset_index()
            tier_counts.columns = ["Risk_Tier", "Count"]
            fig_tier = px.bar(
                tier_counts, x="Risk_Tier", y="Count", color="Risk_Tier",
                color_discrete_map={"Low Risk": "#22c55e", "Moderate Risk": "#eab308", "High Risk": "#f97316", "Critical Risk": "#ef4444"},
                title="Transaction Distribution across Operational Risk Tiers"
            )
            st.plotly_chart(fig_tier, use_container_width=True)

        with col_chart2:
            fig_hist = px.histogram(
                scored, x="Fraud_Probability", nbins=40,
                color="Prediction_Label",
                color_discrete_map={"Legitimate": "#3b82f6", "Flagged Fraud": "#ef4444"},
                title="Distribution of Probabilistic Fraud Risk Scores"
            )
            st.plotly_chart(fig_hist, use_container_width=True)

        st.subheader("🚩 Prioritized Suspicious Transactions Queue")
        flagged_queue = scored[scored["Predicted_Class"] == 1].sort_values(by="Fraud_Probability", ascending=False)
        st.dataframe(flagged_queue[["Fraud_Probability", "Risk_Tier", "Amount", "Time", "V14", "V17", "V12", "V10"]].head(20), use_container_width=True)
    else:
        st.info("Awaiting execution of pipeline to populate monitoring database.")
